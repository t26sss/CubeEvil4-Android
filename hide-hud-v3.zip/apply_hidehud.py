#!/usr/bin/env python3
"""Adds the "Hide HUD" switch (Graphics > Optional features, next to Minimap) to the CURRENT files of the repo with
small anchored edits (no file is replaced as a whole). The switch hides the life gauge in the bottom right corner
(life, ammo, name); the picture is left out by port/whole/patches/0991-hide-life-gauge.patch. It travels with the aim
settings (bit 6 = 64, free), like "Far camera" (bit 3) and "Modern controls" (bit 4). Safe to run twice.
Run from the repo root (order does not matter next to apply_modern_controls.py)."""
import glob, os, re, sys

APP = "port/android-decomp/app/src/main/"
failed = []

def sub1(s, pat, fn, what, path):
    new, n = re.subn(pat, fn, s, count=1, flags=re.M)
    if n == 0:
        failed.append(f"{path}: {what}")
        return s
    print("ok:", path, "-", what)
    return new

def process(path, marker, edits, tail=""):
    s = open(path, encoding="utf-8").read()
    if marker in s:
        print("already done, skipped:", path)
        return
    for pat, fn, what in edits:
        s = sub1(s, pat, fn, what, path)
    open(path, "w", encoding="utf-8").write(s + tail)

# 0. the patch must be there (it calls re4_hud_hidden, which this script adds)
if not os.path.exists("port/whole/patches/0991-hide-life-gauge.patch"):
    print("MISSING: port/whole/patches/0991-hide-life-gauge.patch (unzip the whole zip first)")
    sys.exit(1)

# 1. runtime flag, set by the aim bits
process("port/whole/runtime/aim_options.cpp", "gHideHud", [
    (r"^(std::atomic<bool> gFar\(false\);.*)$",
     lambda m: m.group(1) + "\nstd::atomic<bool> gHideHud(false);  // the app's \"Hide HUD\" (patch 0991)", "flag"),
    (r"^(\s*const bool far = \(bits & 8\) != 0;.*)$",
     lambda m: m.group(1) + "\n    gHideHud.store((bits & 64) != 0);  // bit 6 \"Hide HUD\" (patch 0991)", "bit 6"),
    (r"^(int re4_far_camera\(void\))",
     lambda m: "// Patch 0991 (id_sys.cpp): the app's \"Hide HUD\", 1 = the life gauge is not drawn.\nint re4_hud_hidden(void)\n{\n    return gHideHud.load(std::memory_order_relaxed) ? 1 : 0;\n}\n\n" + m.group(1), "getter"),
])

# 2. JNI + aim bit
process(APP + "cpp/core_mode.cpp", "optHideHud", [
    (r"^(std::atomic<int> optFarCamera\{0\};.*)$",
     lambda m: "std::atomic<int> optHideHud{0};  // the menu's \"Hide HUD\" (bit 6 of the aim bits, patch 0991)\n" + m.group(1), "optHideHud"),
    (r"(\(optFarCamera\.load\(\) \? 8 : 0\))", lambda m: m.group(1) + " | (optHideHud.load() ? 64 : 0)", "aim bit"),
], tail='''
// "Hide HUD" (the menu, Graphics > Optional features): the life gauge in the bottom right corner is left out of the
// picture (patch 0991), sent with the aim settings (bit 6).
extern "C" JNIEXPORT void JNICALL Java_com_ast_re4decomp_CoreBridge_setHideHud(JNIEnv *, jclass, jboolean on) {
  const int want = on == JNI_TRUE ? 1 : 0;
  if (optHideHud.exchange(want) != want) LOG("hide HUD: %s", want ? "on" : "off");
}
''')

process(APP + "java/com/ast/re4decomp/CoreBridge.java", "setHideHud", [
    (r"^(\s*public static native void setFarCamera\(boolean on\);)",
     lambda m: m.group(1) + "\n\n  /** \"Hide HUD\": the life gauge (life, ammo, name) in the bottom right corner is not drawn (patch 0991). */\n  public static native void setHideHud(boolean on);", "native"),
])

# 3. send the saved choice at the start
process(APP + "java/com/ast/re4decomp/CoreActivity.java", "setHideHud", [
    (r"^(\s*)(CoreBridge\.setMinimap\(g\.getBoolean\(\"minimap\", false\)\);)$",
     lambda m: m.group(1) + m.group(2) + "\n" + m.group(1) + "CoreBridge.setHideHud(g.getBoolean(\"hideHud\", false));", "send at start"),
])

# 4. the switch, under Minimap
process(APP + "java/com/ast/re4decomp/CoreMenu.java", "ingame_hide_hud", [
    (r"(?s)^(\s*)(toggle\(buttonsRow\(labelledOptions\(0\)\), R\.string\.ingame_minimap,.*?\n\s*\}\);)",
     lambda m: m.group(1) + m.group(2) + "\n" + m.group(1) +
     "toggle(buttonsRow(labelledOptions(0)), R.string.ingame_hide_hud, graphics.getBoolean(\"hideHud\", false), on -> {\n" + m.group(1) +
     "  graphics.edit().putBoolean(\"hideHud\", on).apply(); CoreBridge.setHideHud(on);\n" + m.group(1) + "});", "toggle"),
])

# 5. the string: not twice (a resource defined in two files stops the build)
extra = APP + "res/values/strings_hidehud.xml"
for f in glob.glob(APP + "res/values/*.xml"):
    if f != extra and 'name="ingame_hide_hud"' in open(f, encoding="utf-8", errors="ignore").read():
        if os.path.exists(extra):
            os.remove(extra)
            print("string already in", f, "- removed strings_hidehud.xml")
        break

if failed:
    print("\nMISSING ANCHORS:\n  " + "\n  ".join(failed))
    sys.exit(1)
