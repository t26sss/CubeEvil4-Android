#!/usr/bin/env python3
"""Adds the "Modern controls" switch to the CURRENT files of the repo with small anchored edits
(no file is replaced as a whole). Run from the repo root. Stops with an error when an anchor is missing."""
import re, sys
APP = "port/android-decomp/app/src/main/"
failed = []

def edit(path, pattern, repl, what, count=1):
    s = open(path, encoding="utf-8").read()
    if "re4_modern" in repl or "odern" in repl:
        pass
    new, n = re.subn(pattern, repl, s, count=count, flags=re.M)
    if n == 0:
        failed.append(f"{path}: {what}")
        return
    open(path, "w", encoding="utf-8").write(new)
    print("ok:", path, "-", what)

def append(path, text, what):
    with open(path, "a", encoding="utf-8") as f:
        f.write(text)
    print("ok:", path, "-", what)

def rep(s):  # literal replacement for re.sub
    return s.replace("\\", "\\\\")

# runtime/aim_options.cpp: the flag, set from bit 4 of the aim bits, and its getter
p = "port/whole/runtime/aim_options.cpp"
s = open(p, encoding="utf-8").read()
def sub1(s, pat, fn, what):
    new, n = re.subn(pat, fn, s, count=1, flags=re.M)
    if n == 0:
        failed.append(f"{p}: {what}")
        return s
    print("ok:", p, "-", what)
    return new
s = sub1(s, r"^(std::atomic<bool> gFar\(false\);.*)$",
         lambda m: m.group(1) + "\nstd::atomic<bool> gModern(false);   // the app's \"Modern controls\" (patch 0990)", "flag")
s = sub1(s, r"^(\s*const bool far = \(bits & 8\) != 0;.*)$",
         lambda m: m.group(1) + "\n    gModern.store((bits & 16) != 0);  // bit 4 \"Modern controls\" (patch 0990)", "bit 4")
s = sub1(s, r"^(int re4_far_camera\(void\))",
         lambda m: "// Patch 0990 (player.cpp): the app's \"Modern controls\".\nint re4_modern_controls(void)\n{\n    return gModern.load(std::memory_order_relaxed) ? 1 : 0;\n}\n\n" + m.group(1), "getter")
open(p, "w", encoding="utf-8").write(s)

# core_mode.cpp
p = APP + "cpp/core_mode.cpp"
s = open(p, encoding="utf-8").read()
s = sub1(s, r"^(std::atomic<int> optFarCamera\{0\};.*)$",
         lambda m: "std::atomic<int> optModern{0};  // the menu's \"Modern controls\" (bit 4 of the aim bits, patch 0990)\n" + m.group(1), "optModern")
s = sub1(s, r"(const int aim = optAim\.load\(\))",
         lambda m: m.group(1) + " | (optModern.load() ? 16 : 0)", "aim bit")
s += '''
// "Modern controls" (the menu, Controls): the left stick moves Leon the way it points, as the camera sees it
// (patch 0990), sent with the aim settings (bit 4).
extern "C" JNIEXPORT void JNICALL Java_com_ast_re4decomp_CoreBridge_setModernControls(JNIEnv *, jclass, jboolean on) {
  const int want = on == JNI_TRUE ? 1 : 0;
  if (optModern.exchange(want) != want) LOG("modern controls: %s", want ? "on" : "off");
}
'''
open(p, "w", encoding="utf-8").write(s)

# CoreBridge.java
p = APP + "java/com/ast/re4decomp/CoreBridge.java"
s = open(p, encoding="utf-8").read()
s = sub1(s, r"^(\s*public static native void setFarCamera\(boolean on\);)",
         lambda m: m.group(1) + "\n\n  /** \"Modern controls\": the left stick moves Leon the way it points, as the camera sees it (patch 0990). */\n  public static native void setModernControls(boolean on);", "native")
open(p, "w", encoding="utf-8").write(s)

# CoreActivity.java
p = APP + "java/com/ast/re4decomp/CoreActivity.java"
s = open(p, encoding="utf-8").read()
s = sub1(s, r"(FAR_CAMERA = \"farCamera\")",
         lambda m: m.group(1) + ",\n      MODERN_CONTROLS = \"modernControls\"", "pref key")
s = sub1(s, r"^(\s*)(CoreBridge\.setFarCamera\(.*\);)$",
         lambda m: m.group(1) + m.group(2) + "\n" + m.group(1) + "CoreBridge.setModernControls(getSharedPreferences(INPUT_PREFS, MODE_PRIVATE).getBoolean(MODERN_CONTROLS, false));", "send at start")
open(p, "w", encoding="utf-8").write(s)

# CoreMenu.java
p = APP + "java/com/ast/re4decomp/CoreMenu.java"
s = open(p, encoding="utf-8").read()
s = sub1(s, r"^(\s*)(toggle\(third, R\.string\.ingame_always_run,.*)$",
         lambda m: m.group(1) + m.group(2) + "\n" + m.group(1) + "MenuLayout.Buttons fourth = buttonsRow(body);\n" + m.group(1) +
         "toggle(fourth, R.string.ingame_modern_controls, input.getBoolean(CoreActivity.MODERN_CONTROLS, false), on -> {\n" + m.group(1) +
         "  input.edit().putBoolean(CoreActivity.MODERN_CONTROLS, on).apply(); CoreBridge.setModernControls(on);\n" + m.group(1) + "});", "toggle row")
s = sub1(s, r"(help\(R\.string\.ingame_always_run_help\);)",
         lambda m: m.group(1) + " help(R.string.ingame_modern_controls_help);", "help")
open(p, "w", encoding="utf-8").write(s)

if failed:
    print("\nMISSING ANCHORS:\n  " + "\n  ".join(failed))
    sys.exit(1)
