#!/usr/bin/env python3
"""Puts back the files an earlier upload of the first zip replaced as a whole: for each one that already
contains the modern-controls change, the newest version from the git history WITHOUT it (the file as the
repo had it before). Needs the full history (actions/checkout with fetch-depth: 0). Run from the repo root."""
import subprocess, sys

APP = "port/android-decomp/app/src/main/"
FILES = [
    "port/whole/runtime/aim_options.cpp",
    APP + "cpp/core_mode.cpp",
    APP + "java/com/ast/re4decomp/CoreActivity.java",
    APP + "java/com/ast/re4decomp/CoreBridge.java",
    APP + "java/com/ast/re4decomp/CoreMenu.java",
    APP + "res/values/strings_ingame.xml",
]
MARKERS = ("gModern", "optModern", "MODERN_CONTROLS", "setModernControls", "ingame_modern_controls")

def git(*a):
    return subprocess.run(["git", *a], capture_output=True)

bad = False
for path in FILES:
    cur = open(path, encoding="utf-8").read()
    if not any(m in cur for m in MARKERS):
        print("untouched:", path)
        continue
    hashes = git("log", "--format=%H", "--", path).stdout.decode().split()
    for h in hashes:
        r = git("show", f"{h}:{path}")
        if r.returncode != 0:
            continue
        old = r.stdout.decode("utf-8", errors="surrogateescape")
        if not any(m in old for m in MARKERS):
            open(path, "w", encoding="utf-8", errors="surrogateescape").write(old)
            print(f"restored {path} from commit {h[:8]}")
            break
    else:
        print("NO CLEAN VERSION FOUND:", path)
        bad = True
sys.exit(1 if bad else 0)
