#!/usr/bin/env python3
"""Walking while aiming with "Modern controls": while aiming, the move stick goes to the game as the C stick
(which the core reads as the walk, patch 0990) and the aim comes from the other source: the controller's right
stick, or the touch C stick (and the look zone's swipes). Small anchored edits, safe to run twice. Run from the
repo root, after apply_touchlook.py. Controllers mapped by the app's own mapping page and keyboards are not covered."""
import re, sys
P = "port/android-decomp/app/src/main/java/com/ast/re4decomp/CoreInput.java"
failed = []

def sub1(s, pat, fn, what):
    new, n = re.subn(pat, fn, s, count=1, flags=re.M)
    if n == 0:
        failed.append(f"{P}: {what}")
        return s
    print("ok:", P, "-", what)
    return new

s = open(P, encoding="utf-8").read()
if "walk while aiming" in s:
    print("already done, skipped:", P)
else:
    # the controller: the move stick walks, the right stick aims
    s = sub1(s, r"^(\s*)(cX = cY = 0;)$",
             lambda m: m.group(1) + m.group(2) + "\n" + m.group(1) + "if (modernLook) {  // walk while aiming: the move stick goes in the C stick\n"
             + m.group(1) + "  cX = d.lx;\n" + m.group(1) + "  cY = d.ly;\n" + m.group(1) + "}", "controller")
    # the touch controls: the C stick aims, the move stick walks
    s = sub1(s, r"^(\s*)if \(touchAiming && touch && touchAim == AIM_LOOK\) \{",
             lambda m: m.group(1) + "if (touchAiming && touch && modernLook) {\n"
             + m.group(1) + "  // walk while aiming: the move stick walks (the C stick of the game), the touch C stick aims\n"
             + m.group(1) + "  cX = mainX;\n" + m.group(1) + "  cY = mainY;\n"
             + m.group(1) + "  mainX = d.cStickX;\n" + m.group(1) + "  mainY = d.cStickY;\n"
             + m.group(1) + "} else if (touchAiming && touch && touchAim == AIM_LOOK) {", "touch")
    open(P, "w", encoding="utf-8").write(s)

if failed:
    print("\nMISSING ANCHORS:\n  " + "\n  ".join(failed))
    sys.exit(1)
